console.log("✅ Dark Pattern Detector content script loaded");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message === "SCAN_PAGE") {

    const text = document.body.innerText.toLowerCase();
    let results = [];

    // ===============================
    // 1️⃣ Forced Cookie Consent
    // ===============================
    const acceptWords = ["accept", "agree", "allow"];
    const rejectWords = [
      "reject",
      "deny",
      "decline",
      "manage",
      "preferences",
      "view preferences",
      "manage consent"
    ];

    const hasAccept = acceptWords.some(w => text.includes(w));
    const hasReject = rejectWords.some(w => text.includes(w));

    if (hasAccept && !hasReject) {
      results.push({
        type: "Forced Cookie Consent",
        evidence: "Accept option present, reject option missing",
        explanation:
          "The website nudges users to accept cookies by hiding or removing rejection choices.",
        confidence: "High"
      });
    }

    // ===============================
    // 2️⃣ Guilt Tripping (NLP-style)
    // ===============================
    const guiltPatterns = [
      "i don't care",
      "i do not care",
      "i prefer to stay uninformed",
      "i like paying more",
      "i don't value my privacy",
      "no thanks, i"
    ];

    guiltPatterns.forEach(phrase => {
      if (text.includes(phrase)) {
        results.push({
          type: "Guilt Tripping (NLP)",
          evidence: phrase,
          explanation:
            "Uses emotionally manipulative language to shame users into consenting.",
          confidence: "High"
        });
      }
    });

    // ===============================
    // 3️⃣ Urgency / Pressure
    // ===============================
    const urgencyWords = [
      "hurry",
      "limited time",
      "act now",
      "offer ends",
      "last chance",
      "only few left"
    ];

    urgencyWords.forEach(word => {
      if (text.includes(word)) {
        results.push({
          type: "Urgency / Pressure",
          evidence: word,
          explanation:
            "Creates artificial urgency to push users into quick decisions.",
          confidence: "Medium"
        });
      }
    });

    // ===============================
    // 4️⃣ Obstruction / Hidden Exit
    // ===============================
    const actionWords = ["continue", "proceed", "next"];
    const cancelWords = ["cancel", "go back", "exit", "close"];

    const hasAction = actionWords.some(w => text.includes(w));
    const hasCancel = cancelWords.some(w => text.includes(w));

    if (hasAction && !hasCancel) {
      results.push({
        type: "Obstruction / Hidden Exit",
        evidence: "Primary action present without clear cancel option",
        explanation:
          "Makes it difficult for users to opt out or reverse a decision.",
        confidence: "Medium"
      });
    }

    sendResponse(results);
  }
});
