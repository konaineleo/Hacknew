document.addEventListener("DOMContentLoaded", () => {
  const scanBtn = document.getElementById("scan");
  const resultsDiv = document.getElementById("results");

  scanBtn.addEventListener("click", () => {
    resultsDiv.innerHTML =
     "<div style='padding:8px;background:#eef2ff;border-radius:6px;color:#3730a3;'>🔍 Scanning page for dark patterns…</div>";


    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      chrome.tabs.sendMessage(tabs[0].id, "SCAN_PAGE", response => {

        if (chrome.runtime.lastError) {
          resultsDiv.innerHTML =
            "⚠ Cannot scan this page. Please refresh and try again.";
          return;
        }

        resultsDiv.innerHTML = "";

        if (!response || response.length === 0) {
          resultsDiv.innerHTML =
            "<div style='padding:8px;background:#e6fffa;border:1px solid #b2f5ea;'>✅ No dark patterns detected</div>";
          return;
        }

        response.forEach(r => {
          const card = document.createElement("div");
          card.style.border = "1px solid #f5c2c7";
          card.style.borderRadius = "6px";
          card.style.boxShadow = "0 1px 3px rgba(0,0,0,0.08)";

          card.style.background = "#fff5f5";
          card.style.padding = "8px";
          card.style.marginBottom = "8px";

          card.innerHTML = `
            <b>⚠ ${r.type}</b>
            <span style="float:right;color:#b91c1c;font-weight:bold;">
              ${r.confidence || "Medium"} Risk
            </span><br><br>

            <b>Evidence:</b> ${r.evidence}<br>
            <b>Why this matters:</b> ${r.explanation}<br><br>

            <b>What you can do:</b>
            <ul style="margin:4px 0 0 16px;">
              <li>Review consent options carefully</li>
              <li>Look for hidden reject or manage settings</li>
              <li>Avoid rushing decisions</li>
            </ul>
          `;

          resultsDiv.appendChild(card);
        });
      });
    });
  });
});
